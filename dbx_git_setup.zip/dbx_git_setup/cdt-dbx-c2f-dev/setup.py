from setuptools import setup, find_packages

setup(
    name='repo_name',
    version='0.0.1',
    author='venkat',
    author_email='venkat@abc.com',
    description='A description of your package',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    entry_points={
        'console_scripts': [
            'main=frameworks.ingest_data.Main:main'
        ]
    },
    install_requires=[
        'setuptools'
    ],
    include_package_data=True,
    package_data={
        'frameworks.ingest_data': ['config_schema.json'],
    },
)